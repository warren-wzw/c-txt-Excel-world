﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using Microsoft.Office.Interop.Excel;
using System.IO;
using System.Windows.Forms.DataVisualization.Charting;
using MSWorld = Microsoft.Office.Interop.Word;

namespace _12._19
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Microsoft.Office.Interop.Excel.Application myexcel = new Microsoft.Office.Interop.Excel.Application();
        private MSWorld.Application m_word;

        private void button1_Click(object sender, EventArgs e)
        {

            int StartRow = 1;

            int m = this.textBox1.Lines.Length;
            int[] rows = new int[m - 1];
            string[] a = textBox1.Text.Split('\n');
            for (int i = 0; i < m - 1; i++)
            {
                rows[i] = i + 1;
            }
            string[] cols = { "数据" };

            double[] data = new double[m - 1];

            for (int i = 0; i < m - 1; i++)
            {
                data[i] = double.Parse(a[i]);
            }


            myexcel = new Microsoft.Office.Interop.Excel.Application();
            myexcel.Application.Workbooks.Add(Type.Missing);
            myexcel.Caption = "excel test";
            myexcel.Visible = true;
            Worksheet sheet = (Worksheet)myexcel.ActiveWorkbook.Worksheets.Add(Missing.Value, Missing.Value, Missing.Value, Missing.Value);
            sheet.Name = "表2";
            SheetControl sc = new SheetControl(sheet);
            sc.CreateChart(sheet.get_Range("F2:o20"), sheet.get_Range((Microsoft.Office.Interop.Excel.Range)sheet.Cells[2, 2], (Microsoft.Office.Interop.Excel.Range)sheet.Cells[2 + rows.Length, 2 + cols.Length]), XlChartType.xlColumnClustered, Microsoft.Office.Interop.Excel.XlRowCol.xlColumns, " 柱状图", null, "数据");
            sc.CreateTable2("数据表", rows, cols, data, 2, 2);
            sc.SetType();

            //

            for (int row = StartRow; row <= sheet.UsedRange.Rows.Count; row++)
            {


                if (sheet.Shapes.Count > row - StartRow)
                {
                    Microsoft.Office.Interop.Excel.Shape s = sheet.Shapes.Item(row - StartRow + 1) as Microsoft.Office.Interop.Excel.Shape;

                    Clipboard.Clear();
                    s.CopyPicture(Appearance.Button, Microsoft.Office.Interop.Excel.XlCopyPictureFormat.xlBitmap);
                    IDataObject iData = Clipboard.GetDataObject();


                    if (iData != null && iData.GetDataPresent(DataFormats.Bitmap))
                    {
                        System.Drawing.Image img = Clipboard.GetImage();
                        if (img != null)
                        {

                            img.Save(@"D:\桌面\123.jpg", System.Drawing.Imaging.ImageFormat.Jpeg);
                        }
                    }
                    else
                    {
                    }

                }




            }

        }

        private void button3_Click(object sender, EventArgs e)
        {

            OpenFileDialog ofd1 = new OpenFileDialog();
            ofd1.InitialDirectory = "D:\\";
            ofd1.FileName = "Document";
            ofd1.Title = "请选择一个文本文件";
            ofd1.Filter = "文本文件(*.text)|*.text|所有文件(*.*)|*.*";
            ofd1.FilterIndex = 2;
            ofd1.RestoreDirectory = true;
            ofd1.ShowHelp = true;
            if (ofd1.ShowDialog() == DialogResult.OK)
            {
                textBox2.Text = ofd1.FileName;
                textBox1.Text = null;
                string[] wzw = new string[100];
                int i = 0;
                if (textBox2.Text != "")
                {
                    StreamReader sr = new StreamReader(textBox2.Text, Encoding.Default);
                    string line;

                    List<double> dataArray = new List<double>();
                    while ((line = sr.ReadLine()) != null)
                    {
                        dataArray.Add(double.Parse(line));
                        wzw[i] = line;
                        i++;
                    }
                    for (int j = 0; j < dataArray.Count; j++)
                    {
                        textBox1.Text += wzw[j] + "\r\n";
                    }
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string[] wzw = new string[100];
            int i = 0;
            if (textBox2.Text != "")
            {
                StreamReader sr = new StreamReader(textBox2.Text, Encoding.Default);
                string line;

                List<double> dataArray = new List<double>();
                while ((line = sr.ReadLine()) != null)
                {
                    dataArray.Add(double.Parse(line));
                    wzw[i] = line;
                    i++;
                }
                //for (int j = 0; j < 20; j++)
                //{
                //    textBox1.Text += wzw[j]+ "\r\n";
                //}

                chart1.Width = 400;
                chart1.Height = 300;
                chart1.BackColor = Color.Azure;
                Title t2 = new Title("曲线图", Docking.Top, new System.Drawing.Font("宋体", 14, System.Drawing.FontStyle.Bold), System.Drawing.Color.FromArgb(26, 59, 105));//图片标题
                chart1.Titles.Add(t2);

                System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series("first")
                {
                    Color = Color.Purple,
                    ChartType = SeriesChartType.Spline,



                    BorderWidth = 2,
                    ShadowOffset = 1,
                    IsVisibleInLegend = false,

                    MarkerStyle = MarkerStyle.Circle,
                    MarkerSize = 4
                };


                for (int iii = 0; iii < dataArray.Count; iii++)
                {
                    series1.Points.AddXY((iii + 1).ToString(), dataArray[iii]);
                }
                chart1.Series.Clear();
                chart1.Series.Add(series1);

                chart1.ChartAreas["ChartArea1"].AxisX.IsMarginVisible = false;
                chart1.ChartAreas["ChartArea1"].Area3DStyle.Enable3D = false;

                chart1.ChartAreas["ChartArea1"].ShadowColor = Color.Purple;
                chart1.ChartAreas["ChartArea1"].BackColor = Color.White;
                chart1.ChartAreas["ChartArea1"].BackGradientStyle = GradientStyle.TopBottom;
                chart1.ChartAreas["ChartArea1"].BackSecondaryColor = Color.White;

                chart1.ChartAreas["ChartArea1"].AxisX.LineColor = Color.White;
                chart1.ChartAreas["ChartArea1"].AxisY.LineColor = Color.Purple;
                chart1.ChartAreas["ChartArea1"].AxisX.LineWidth = 2;
                chart1.ChartAreas["ChartArea1"].AxisY.LineWidth = 2;
                chart1.ChartAreas["ChartArea1"].AxisY.Title = "数据";
                chart1.ChartAreas["ChartArea1"].AxisX.Title = "编号";
                chart1.ChartAreas["ChartArea1"].AxisY.Minimum = 0;

                chart1.ChartAreas["ChartArea1"].AxisX.LabelStyle.Enabled = true;


                chart1.ChartAreas["ChartArea1"].AxisX.MajorGrid.LineColor = Color.Purple;
                chart1.ChartAreas["ChartArea1"].AxisY.MajorGrid.LineColor = Color.Purple;

                chart1.ChartAreas["ChartArea1"].AxisX.Interval = 1;
                chart1.ChartAreas["ChartArea1"].AxisY.Interval = 10;

                chart1.ChartAreas["ChartArea1"].AxisX.MajorGrid.Interval = 1;


            }
        }
        class SheetControl
        {
            Worksheet sheet;
            public SheetControl(Worksheet sheet)
            {
                this.sheet = sheet;
            }


            public void CreateChart(Microsoft.Office.Interop.Excel.Range rg, Microsoft.Office.Interop.Excel.Range data, Object type = null, Microsoft.Office.Interop.Excel.XlRowCol xlrc = Microsoft.Office.Interop.Excel.XlRowCol.xlColumns, string title = null, string CategoryTitle = null, string ValueTitle = null)
            {
                ChartObjects charts = (ChartObjects)sheet.ChartObjects(Type.Missing);
                ChartObject chartObj = charts.Add(rg.Left, rg.Top, rg.Width, rg.Height);
                Microsoft.Office.Interop.Excel.Chart chart = chartObj.Chart;
                chart.ChartWizard(data, type, Type.Missing, xlrc, 1, 1, true, title, CategoryTitle, ValueTitle, Type.Missing);
                chart.Legend.Position = Microsoft.Office.Interop.Excel.XlLegendPosition.xlLegendPositionTop;

            }


            public void CreateTable(string title, string[] rows, string[] cols, string[,] data, int startRow, int startCol)
            {
                sheet.Cells[startRow, startCol] = title;
                for (int i = 0; i < cols.Length; i++)
                {
                    sheet.Cells[startRow, i + startCol + 1] = cols[i];
                }
                for (int i = 0; i < rows.Length; i++)
                {
                    sheet.Cells[i + startRow + 1, startCol] = rows[i];
                    for (int j = 0; j < cols.Length; j++)
                    {
                        sheet.Cells[i + startRow + 1, j + startCol + 1] = data[i, j];
                    }
                }
            }
            //2
            public void CreateTable2(string title, int[] rows, string[] cols, double[] data, int startRow, int startCol)
            {
                sheet.Cells[startRow, startCol] = title;
                for (int i = 0; i < cols.Length; i++)
                {
                    sheet.Cells[startRow, i + startCol + 1] = cols[i];
                }
                for (int i = 0; i < rows.Length; i++)
                {
                    sheet.Cells[i + startRow + 1, startCol] = rows[i];
                    for (int j = 0; j < cols.Length; j++)
                    {
                        sheet.Cells[i + startRow + 1, j + startCol + 1] = data[i];
                    }
                }
            }

            public void SetType()
            {

                sheet.UsedRange.Font.Size = 12;
                sheet.UsedRange.Font.Name = "华文楷体";
                sheet.UsedRange.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                sheet.UsedRange.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter;
                sheet.UsedRange.Borders.LineStyle = 1;
                sheet.UsedRange.Columns.AutoFit();
                sheet.UsedRange.Rows.AutoFit();

                sheet.UsedRange.BorderAround(Microsoft.Office.Interop.Excel.XlLineStyle.xlDouble, Microsoft.Office.Interop.Excel.XlBorderWeight.xlThick, Microsoft.Office.Interop.Excel.XlColorIndex.xlColorIndexAutomatic, System.Drawing.Color.Black.ToArgb());
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.SaveFileDialog objSave = new System.Windows.Forms.SaveFileDialog();
            objSave.Filter = "(*.doc)|*.doc|" + "(*.*)|*.*";//+ "(*.txt)|*.txt|"

            objSave.FileName = DateTime.Now.ToString("yyyy-MM-dd") + ".doc";

            if (objSave.ShowDialog() == DialogResult.OK)
            {

                Microsoft.Office.Interop.Word.Application MyWord = new Microsoft.Office.Interop.Word.Application();
                Microsoft.Office.Interop.Word.Document MyDoc;

                Object Nothing = System.Reflection.Missing.Value;

                MyDoc = MyWord.Documents.Add(ref Nothing, ref Nothing, ref Nothing, ref Nothing);

                MyDoc.Paragraphs.Last.Range.Font.Name = "宋体";

                MyDoc.Paragraphs.Last.Range.Text = this.textBox1.Text;
                //MyDoc.Paragraphs.Last.Range.Text = this.chart1.Text;
                string FileName = @"D:\桌面\123.jpg";
                object MyFileName = objSave.FileName;
                //
                Object range = MyDoc.Paragraphs.Last.Range;
                Object linkToFile = false;
                Object saveWithDocument = true;
                MyDoc.InlineShapes.AddPicture(FileName, ref linkToFile, ref saveWithDocument, ref range);
                //MyWord.Selection.ParagraphFormat.Alignment = MSWorld.WdParagraphAlignment.wdAlignParagraphCenter;
                //


             
                //将WordDoc文档对象的内容保存为DOC文档 
                MyDoc.SaveAs(ref MyFileName, ref Nothing, ref Nothing, ref Nothing, ref Nothing, ref Nothing, ref Nothing, ref Nothing, ref Nothing, ref Nothing, ref Nothing, ref Nothing, ref Nothing, ref Nothing, ref Nothing, ref Nothing);
                //关闭WordDoc文档对象 
                MyDoc.Close(ref Nothing, ref Nothing, ref Nothing);
                //关闭WordApp组件对象 
                MyWord.Quit(ref Nothing, ref Nothing, ref Nothing);
                MessageBox.Show("文件保存成功", "信息提示", MessageBoxButtons.OK, MessageBoxIcon.Information);

                m_word = new MSWorld.Application();
                Object filename = objSave.FileName;
                Object filefullname = objSave.FileName;
                Object confirmConversions = Type.Missing;
                Object readOnly = Type.Missing;
                Object addToRecentFiles = Type.Missing;
                Object passwordDocument = Type.Missing;
                Object passwordTemplate = Type.Missing;
                Object revert = Type.Missing;
                Object writePasswordDocument = Type.Missing;
                Object writePasswordTemplate = Type.Missing;
                Object format = Type.Missing;
                Object encoding = Type.Missing;
                Object visible = Type.Missing;
                Object openConflictDocument = Type.Missing;
                Object openAndRepair = Type.Missing;
                Object documentDirection = Type.Missing;
                Object noEncodingDialog = Type.Missing;

                for (int i = 1; i <= m_word.Documents.Count; i++)
                {
                    String str = m_word.Documents[i].FullName.ToString();
                    if (str == filefullname.ToString())
                    {
                        MessageBox.Show("请勿重复打开该文档");
                        return;
                    }
                }
                try
                {
                    m_word.Documents.Open(ref filefullname,
                        ref confirmConversions, ref readOnly, ref addToRecentFiles,
                        ref passwordDocument, ref passwordTemplate, ref revert,
                        ref writePasswordDocument, ref writePasswordTemplate,
                        ref format, ref encoding, ref visible, ref openConflictDocument,
                        ref openAndRepair, ref documentDirection, ref noEncodingDialog
                        );
                    m_word.Visible = true;
                }
                catch (System.Exception)
                {
                    MessageBox.Show("打开Word文档出错");
                }


            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            



 

          


        }



    }
}

